import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import { BaseApplicationCustomizer, PlaceholderContent, PlaceholderName} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';
require('../assets/Main.css');

// Change Name (Top) if needed
export interface IBrandingExtensionApplicationCustomizerProperties {Top: string;}

export default class BrandingExtensionApplicationCustomizer
  extends BaseApplicationCustomizer<IBrandingExtensionApplicationCustomizerProperties> {

  // Adds
  private _topPlaceholder: PlaceholderContent | undefined;
  public _onDispose: (placeholderContent: PlaceholderContent) => void;

  @override
  public onInit(): Promise<void> {
    //Adds
    this.context.placeholderProvider.changedEvent.add(this, this._renderPlaceHolders);
    this._renderPlaceHolders();
      return Promise.resolve();
  }

  private _renderPlaceHolders(): void {
  
    // Handling the top placeholder
    if (!this._topPlaceholder) {
      this._topPlaceholder =
        this.context.placeholderProvider.tryCreateContent(
          PlaceholderName.Top,
          { onDispose: this._onDispose });
  
      // The extension should not assume that the expected placeholder is available.
      if (!this._topPlaceholder) {
        console.error('The expected placeholder (Top) was not found.');
          return;
      }
  
      if (this.properties) {
        let topString: string = this.properties.Top;
          if (!topString) {
            topString = 'Report an incident';
          }
  
          // TOP PLACEHOLDER Content, Add HTML in the inner HTML if you like..
          if (this._topPlaceholder.domElement) {
            this._topPlaceholder.domElement.innerHTML = ``;
          }

      }}
  
  }}