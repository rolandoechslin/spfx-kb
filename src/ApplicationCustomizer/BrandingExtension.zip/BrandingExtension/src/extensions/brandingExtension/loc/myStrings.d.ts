declare interface IBrandingExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'BrandingExtensionApplicationCustomizerStrings' {
  const strings: IBrandingExtensionApplicationCustomizerStrings;
  export = strings;
}
