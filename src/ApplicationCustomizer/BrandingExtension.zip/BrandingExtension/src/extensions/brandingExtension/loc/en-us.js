define([], function() {
  return {
    "Title": "BrandingExtensionApplicationCustomizer"
  }
});