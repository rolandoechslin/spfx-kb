import { BaseApplicationCustomizer, PlaceholderContent } from '@microsoft/sp-application-base';
export interface IBrandingExtensionApplicationCustomizerProperties {
    Top: string;
}
export default class BrandingExtensionApplicationCustomizer extends BaseApplicationCustomizer<IBrandingExtensionApplicationCustomizerProperties> {
    private _topPlaceholder;
    _onDispose: (placeholderContent: PlaceholderContent) => void;
    onInit(): Promise<void>;
    private _renderPlaceHolders;
}
//# sourceMappingURL=BrandingExtensionApplicationCustomizer.d.ts.map